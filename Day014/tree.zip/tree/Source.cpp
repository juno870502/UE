//#include <iostream>
//#include <list>
//using namespace std;
//
//class Node
//{
//public:
//	Node(int Init = 0) 
//	{
//		Data = Init;
//	}
//	Node* Parent;
//	int Data;
//
//	list<Node*> Child;
//
//	Node* GetChild(int Index)
//	{
//		list<Node*>::iterator IChild = Child.begin();
//		for (size_t i = 0; i < Index; i++)
//		{
//			IChild++;
//		}
//		return *IChild;
//	}
//};
//
//class Tree
//{
//public:
//	Node* Root;
//
//	void AddChild(Node* Parent, Node* Child)
//	{
//		Parent->Child.push_back(Child);
//		Child->Parent = Parent;
//	}
//	void AddChild(Node* Parent, int Value)
//	{
//		Node* NewNode = new Node(Value);
//		Parent->Child.push_back(NewNode);
//		NewNode->Parent = Parent;
//	}
//
//	int GetChildrenCount(Node* Where)
//	{
//		return Where->Child.size();
//	}
//
//
//
//};
//
//int main2()
//{
//	Node* node = new Node(1);
//	Tree* TestTree = new Tree;
//	TestTree->Root = node;
//
//	Node* childNode = new Node(2);
//	TestTree->AddChild(TestTree->Root, 2);
//	TestTree->AddChild(TestTree->Root->GetChild(0), 3);
//	TestTree->AddChild(TestTree->Root, 4);
//	TestTree->AddChild(TestTree->Root->GetChild(1), 5);
//	TestTree->AddChild(TestTree->Root->GetChild(1), 6);
//
//	return 0;
//}