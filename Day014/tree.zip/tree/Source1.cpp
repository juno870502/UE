#include <iostream>
using namespace std;
class Node
{
public:
	Node(int Init = 0)
	{
		Data = Init;
		Parent = nullptr;
		LeftChild = nullptr;
		RightChild = nullptr;
	}
	Node* Parent;
	int Data;
	Node* LeftChild;
	Node* RightChild;
};
class BSTree
{
public:
	BSTree() { Root = nullptr; }
	void Insert(int Value)
	{
		Node* Current = Root;
		if (Root == nullptr) // ��Ʈ�� ����. ó�� ����
		{
			Root = new Node(Value);
		}
		while (Current != nullptr)
		{
			if (Value < Current->Data)
			{
				if (Current->LeftChild == nullptr)
				{
					Node* NewNode = new Node(Value);
					Current->LeftChild = NewNode;
					NewNode->Parent = Current;
					Current = nullptr;
				}
				else
				{
					Current = Current->LeftChild;
				}
			}
			else
			{
				if (Current->RightChild == nullptr)
				{
					Node* NewNode = new Node(Value);
					Current->RightChild = NewNode;
					NewNode->Parent = Current;
					Current = nullptr;
				}
				else
				{
					Current = Current->RightChild;
				}
			}
		}
	}
	Node* Find(int Value)
	{
		Node* Current = Root;
		
		while (Current != nullptr)
		{
			if (Current->Data == Value)
			{
				return Current;
			}

			if (Current->Data < Value)
			{
				Current = Current->RightChild;
			}
			else
			{
				Current = Current->LeftChild;
			}
		}
		return nullptr;
	}
	void Preorder(Node* SearchNode )
	{
		if (SearchNode)
		{
			cout << SearchNode->Data << endl;

			if (SearchNode->LeftChild)
			{
				Preorder(SearchNode->LeftChild);
			}

			if (SearchNode->RightChild)
			{
				Preorder(SearchNode->RightChild);
			}
		}
	}
	void Postorder(Node* SearchNode)
	{
		if (SearchNode)
		{
			
			if (SearchNode->LeftChild)
			{
				Postorder(SearchNode->LeftChild);
			}

			if (SearchNode->RightChild)
			{
				Postorder(SearchNode->RightChild);
			}

			cout << SearchNode->Data << endl;
		}
	}

	void Inorder(Node* SearchNode)
	{
		if (SearchNode)
		{
			if (SearchNode->LeftChild)
			{
				Inorder(SearchNode->LeftChild);
			}

			cout << SearchNode->Data << endl;

			if (SearchNode->RightChild)
			{
				Inorder(SearchNode->RightChild);
			}
			
		}
	}
	Node* GetRoot() { return Root; }
protected:
	Node* Root;
};

int main()
{
	BSTree TestTree;
	TestTree.Insert(4);
	TestTree.Insert(2);
	TestTree.Insert(6);
	TestTree.Insert(1);
	TestTree.Insert(3);
	TestTree.Insert(5);
	TestTree.Insert(7);

	TestTree.Preorder(TestTree.GetRoot());
	cout << endl;
	TestTree.Inorder(TestTree.GetRoot());
	cout << endl;
	TestTree.Postorder(TestTree.GetRoot());
	cout << endl;
	return 0;
}