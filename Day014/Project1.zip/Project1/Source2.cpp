//#include<iostream>
//#include<queue>
//#include<stack>
//using namespace std;
//
//#define MAX 5
//int Maze[MAX][MAX] = {
//	{0, 1, 1, 1, 0},
//	{0, 0, 0, 0, 0},
//	{1, 0, 1, 1, 1},
//	{1, 0, 1, 1, 1},
//	{1, 0, 0, 0, 0}
//};
//
//class Point
//{
//public:
//	Point(int x = 0, int y = 0) { X = x; Y = y; }
//	void PrintPoint() { cout << "(" << X << ", " << Y << ")" << endl; }
//	int X;
//	int Y;
//};
//stack<Point> tempQueue;
//
//bool REscape(Point current)
//{
//	if (current.X < 0 || current.Y < 0 || current.X >= MAX || current.Y >= MAX)
//	{
//		return false;
//	}
//	else if (Maze[current.Y][current.X] == 1 || Maze[current.Y][current.X] == 3)
//	{
//		tempQueue.pop();
//		return false;
//	}
//	else if (Maze[current.Y][current.X] == 2)
//	{
//		Maze[current.Y][current.X] = 3;
//		return false;
//	}
//	Maze[current.Y][current.X] = 2;
//	tempQueue.push(current);
//	//Point temp = tempQueue.top();
//	//temp.PrintPoint();
//
//	if (current.X == MAX && current.Y == MAX)
//	{
//		return true;
//	}
//	Point UP(current.X, current.Y - 1);
//	Point RIGHT(current.X+1, current.Y);
//	Point DOWN(current.X, current.Y + 1);
//	Point LEFT(current.X-4, current.Y);
//	if (REscape(UP) || REscape(RIGHT) || REscape(DOWN)|| REscape(LEFT))
//	{
//		
//		return true;
//	}
//	else
//	{
//		//tempQueue.pop();
//	}
//}
//#define UP 0
//#define RIGHT 1
//#define DOWN 2
//#define LEFT 3
//
//void WhileEscape()
//{
//	Point current;
//	stack<Point> path;
//	while (current.X != 4 || current.Y != 4)
//	{
//		path.push(current);
//		for (int i = UP; i <= LEFT; i++)
//		{
//			
//		}
//		
//	}
//}
//
//int main()
//{
//	Point p;
//	REscape(p);
//	cout << "����" << endl;
//	while (!tempQueue.empty())
//	{
//		Point temp = tempQueue.top();
//		temp.PrintPoint();
//		tempQueue.pop();
//	}
//	return 0;
//}