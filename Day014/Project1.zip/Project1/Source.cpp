#include<iostream>

using namespace std;

int Array[] = {
	1,2,3
};

//void Func()
//{
//	int count = sizeof(Array) / sizeof(int);
//	vector<int> CountArray = { 1, 1 };
//	for (int i = 1; i < count; ++i)
//	{
//		CountArray.push_back(1);
//		for (int j = i; j > 0; --j)
//		{
//			CountArray[j] = CountArray[j] + CountArray[j - 1];
//		}
//	}
//
//	for (int i = 1; i < CountArray.size(); i++)
//	{
//		for (int j = 0; j < CountArray[i]; j++)
//		{
//			cout << Array[j] << endl;
//		}
//	}
//	
//	int Num = (1 << count) - 1;
//	int i = 0;
//	int j = 0;
//	while (Num > 0)
//	{
//
//		cout << endl;
//		Num--;
//	}
//}

void Func2()
{
	int count = sizeof(Array) / sizeof(int);
	int Num = (1 << count);
	for (int i = 0; i < Num; i++)
	{
		for (int j = 0; j < count; j++)
		{
			if (i & (1 << j))
			{
				cout << Array[j] << ",";
			}
		}
		cout << endl;
	}
}


int main()
{
	Func2();

	return 0;
}