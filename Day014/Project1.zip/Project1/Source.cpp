#include<iostream>
#include <string>
using namespace std;

int Array[] = {
	1, 2, 3
};

void Func()
{
	int count = sizeof(Array)/sizeof(int);
	int Num = (1 << count) - 1;
	int i = 0;
	int j = 0;
	while (Num > 0)
	{

		cout << endl;
		Num--;
	}
}


int main()
{
	Func();

	return 0;
}