//#include<iostream>
//using namespace std;
//float Point1[] = {
//	0,0
//};
//float Point2[] = {
//	10,10
//};
//float Circle[] = {
//	20,20,1
//};
//
//bool Func(float* Point1, float* Point2, float* Circle)
//{
//	float pointx1 = Point1[0];
//	float pointy1 = Point1[1];
//	float pointx2 = Point2[0];
//	float pointy2 = Point2[1];
//	float opointx = Circle[0];
//	float opointy = Circle[1];
//	float r = Circle[2];
//	float m = (pointy2 - pointy1) / (pointx2 - pointx1);
//	float a = m;
//	float b = -1;
//	float c = -m * pointx1 + pointy1;
//	float d = sqrt((a*opointx + b * opointy + c)*(a*opointx + b * opointy + c) / (a*a) + (b*b));
//	if (r > d)
//	{
//		return true;
//	}
//	else
//	{
//		return false;
//	}
//
//}
//int main()
//{
//	if (Func(Point1, Point2, Circle))
//	{
//		cout << "�浹" << endl;
//	}
//	else
//	{
//		cout << "�浹X" << endl;
//	}
//	return 0;
//}