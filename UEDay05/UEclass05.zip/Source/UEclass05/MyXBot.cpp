// Fill out your copyright notice in the Description page of Project Settings.

#include "MyXBot.h"

#include "Components/InputComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Animation/AnimationAsset.h"
#include "Components/CapsuleComponent.h"

#include "ConstructorHelpers.h"
#include "Kismet/KismetMathLibrary.h"


// Sets default values
AMyXBot::AMyXBot()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	
	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	SpringArm->SetupAttachment(RootComponent);
	Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
	Camera->SetupAttachment(SpringArm);
//	Movement = GetCharacterMovement();

	SpringArm->bUsePawnControlRotation = true;
	SpringArm->bInheritRoll = false;
	/*GetCharacterMovement()->bUseControllerDesiredRotation = true;
	GetCharacterMovement()->bOrientRotationToMovement = true;*/

	//const USkeletalMeshComponent* Mesh = GetMesh();
	GetMesh()->SetRelativeLocation(FVector(0, 0, -GetCapsuleComponent()->GetScaledCapsuleHalfHeight()));
	GetMesh()->SetRelativeRotation(FRotator(0, -90, 0));
	
	static ConstructorHelpers::FObjectFinder<USkeletalMesh> SK_Mesh(TEXT("SkeletalMesh'/Game/Character/xbot.xbot'"));
	if (SK_Mesh.Succeeded())
	{
		GetMesh()->SetSkeletalMesh(SK_Mesh.Object);
	}

	GetMesh()->SetAnimationMode(EAnimationMode::AnimationBlueprint);
	static ConstructorHelpers::FClassFinder<UAnimInstance> DefaultAnim(TEXT("AnimBlueprint'/Game/blueprints/Animations/BP_ANim.BP_ANim_C'"));
	if (DefaultAnim.Succeeded())
	{
		UE_LOG(LogClass, Warning, TEXT("AAAAAAAAAAAA"));
		GetMesh()->SetAnimInstanceClass(DefaultAnim.Class);
	}
	
}

// Called when the game starts or when spawned
void AMyXBot::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AMyXBot::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	AddMovementInput(GetActorRightVector());
}

// Called to bind functionality to input
void AMyXBot::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	PlayerInputComponent->BindAxis(TEXT("Forward"), this, &AMyXBot::MoveForward);
	PlayerInputComponent->BindAxis(TEXT("Right"), this, &AMyXBot::MoveRight);
	PlayerInputComponent->BindAxis(TEXT("Yaw"), this, &AMyXBot::Yaw);
	PlayerInputComponent->BindAxis(TEXT("Pitch"), this, &AMyXBot::Pitch);
}

void AMyXBot::MoveForward(float Value)
{
	ForwardValue = Value;
	if (Value != 0)
	{
		//FRotator ViewRotatoion = FRotator(0, GetControlRotation().Yaw, 0);
		//FVector InputVector = UKismetMathLibrary::GetForwardVector(ViewRotatoion);

		//AddMovementInput(InputVector, Value);
		AddMovementInput(GetActorForwardVector(), Value);
		SpineAngle = 0;
	}
}

void AMyXBot::MoveRight(float Value)
{
	RightValue = Value;
	if (Value != 0)
	{
		//AddMovementInput(UKismetMathLibrary::GetRightVector(FRotator(0, Camera->GetComponentRotation().Yaw, 0)), Value);
		AddMovementInput(GetActorRightVector(), Value);
		SpineAngle = Value > 0 ? 60 : -60;
	}
	
}

void AMyXBot::Yaw(float Value)
{
	if (Value != 0)
	{
		AddControllerYawInput(Value);
	}
}

void AMyXBot::Pitch(float Value)
{
	if (Value != 0)
	{
		AddControllerPitchInput(Value);
	}
}

