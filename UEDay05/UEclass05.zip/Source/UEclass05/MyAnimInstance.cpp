// Fill out your copyright notice in the Description page of Project Settings.

#include "MyAnimInstance.h"
#include "MyXBot.h"
#include "GameFramework/CharacterMovementComponent.h"

void UMyAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);

	AMyXBot* Pawn = Cast<AMyXBot>(TryGetPawnOwner());
	if (Pawn && Pawn->IsValidLowLevel())
	{
		bIsSpeed = Pawn->GetCharacterMovement()->Velocity.Size() > 0 ? true : false;

		
		//Forward 1 0 -1
		//Right 1 0 -1
		//45, 90, 135, 180, 225, 270, 315, 360
		if (Pawn->ForwardValue == 1)
		{
			Angle = 45 * Pawn->RightValue;
		}
		else if (Pawn->ForwardValue == 0)
		{
			Angle = 90 * Pawn->RightValue;
		}
		else
		{
			Angle = -45 * Pawn->RightValue;
		}
		fSpineAngle = Pawn->SpineAngle;
	}
}
