#include <iostream>
#include "Stack.h"
#include "ListStack.h"

using namespace std;




int main()
{
	/*Stack MyStack(20);
	int i = 0;
	while (!MyStack.IsFull())
	{
		MyStack.Push(++i);
	}
	
	MyStack.Resize(10);

	while (!MyStack.IsEmpty())
	{
		cout << MyStack.Pop() << " ";
	}*/
	ListStack<int> IntStack;
	for (size_t i = 1; i <= 11; i++)
	{
		IntStack.Push(i);
	}
	cout << "Size : " << IntStack.GetSize() << endl;
	while (!IntStack.IsEmpty())
	{
		cout << IntStack.Pop() << endl;
	}
}