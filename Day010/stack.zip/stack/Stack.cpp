#include "Stack.h"

Stack::Stack(int StackSize)
{
	Data = new int[StackSize];
	Capacity = StackSize;
	Size = 0;
}

Stack::~Stack()
{
	delete[] Data;
}
bool Stack::Push(int Value)
{
	if (Size < Capacity)
	{
		Data[Size] = Value;
		++Size;
		return true;
	}
	else
	{
		return false;
	}

}
int Stack::Pop()
{
	if (Size > 0)
	{
		return Data[--Size];
	}
	else
	{
		return -1;
	}
}
int Stack::GetSize()
{
	return Size;
}
bool Stack::IsEmpty()
{
	return(Size == 0);
}
bool Stack::IsFull()
{
	return (Size == Capacity);
}
bool Stack::Resize(int NewSize)
{
	////����ó��
	//if (NewSize <= 0 || NewSize == Capacity)
	//{
	//	return false;
	//}
	//Stack* NewStack = new Stack(NewSize);
	////����ó��
	//if (NewStack == nullptr)
	//{
	//	return false;
	//}

	//Stack TempData = Stack(Capacity);
	//while (!this->IsEmpty())
	//{
	//	TempData.Push(this->Pop());
	//}
	//while (!NewStack->IsFull())
	//{
	//	NewStack->Push(TempData.Pop());
	//}
	//Size = NewStack->GetSize();
	//Capacity = NewStack->Capacity;
	//Data = NewStack->Data;
	//return true;

	//����ó��
	if (NewSize <= 0 || NewSize == Capacity)
	{
		return false;
	}
	int* NewData = new int[NewSize];
	//����ó��
	if (NewData == nullptr)
	{
		return false;
	}
	Capacity = NewSize;
	Size = Size > NewSize ? NewSize : Size;
	for (size_t i = 0; i < Size; i++)
	{
		NewData[i] = Data[i];
	}
	delete[] Data;
	Data = NewData;

	return true;
}