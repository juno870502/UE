#pragma once
class Stack
{
public:
	Stack(int StackSize = 10);
	~Stack();

	bool Push(int Value);
	int Pop();
	int GetSize();
	bool IsEmpty();
	bool IsFull();
	bool Resize(int NewSize);
protected:
	int Capacity = 100;
	int* Data;
	int Size;
};