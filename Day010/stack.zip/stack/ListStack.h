#pragma once
#include "List.h"

template <typename T>
class ListStack : public List<T>
{
public:
	ListStack<T>();
	~ListStack<T>();

	void Push(T value);
	T Pop();

	bool IsEmpty();
	int GetSize();
};

template<typename T>
inline ListStack<T>::ListStack()
{
}

template<typename T>
inline ListStack<T>::~ListStack()
{
}

template<typename T>
inline void ListStack<T>::Push(T value)
{
	List<T>::PushBack(value);
}

template<typename T>
inline T ListStack<T>::Pop()
{
	T value = List<T>::Tail->Prev->Data;
	List<T>::Remove(List<T>::Iterator(List<T>::Tail->Prev));
	return value;
}

template<typename T>
inline bool ListStack<T>::IsEmpty()
{
	return List<T>::GetSize() == 0;
}

template<typename T>
inline int ListStack<T>::GetSize()
{
	return List<T>::GetSize();
}
