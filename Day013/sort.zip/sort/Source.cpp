#include <iostream>
#include <algorithm>
#include "Source.h"

using namespace std;

void BubbleSort(int* Data, int n)
{
	for (size_t i = 0; i < n-1; i++)
	{
		for (size_t j = i; j < n-1; j++)
		{
			if (Data[j] > Data[j+1])
			{
				swap(Data[j], Data[j+1]);
			}
			//��¿�
			for (size_t k = 0; k < n; k++)
			{
				cout << Data[k] << ", ";
			}
			cout << endl;
		}
	}
}

void SelectionSort(int* Data, int n, bool(*fp)(int, int))
{
	for (size_t i = 0; i < n; i++)
	{
		for (size_t j = i+1; j < n; j++)
		{
			//if (cmp(Data[i],Data[j]))
			if (fp(Data[i],Data[j]))
			{
				swap(Data[i], Data[j]);
			}
			//��¿�
			for (size_t k = 0; k < n; k++)
			{
				cout << Data[k] << ", ";
			}
			cout << endl;
		}
	}
}

int Partition(int* Data, int begin, int end)
{
	//int Pivot = Data[end];
	//int min = begin - 1;
	//for (size_t max = begin; max < end - 1; max++)
	//{
	//	if (Data[max] <= Pivot)
	//	{
	//		min++;
	//		swap(Data[min], Data[max]);
	//	}
	//}
	//swap(Data[min + 1], Data[end]);
	//return min + 1;

	int Pivot = Data[end];
	int max = end-1;
	int min = begin;
	while (min < max)
	{
		if (Data[min] > Pivot && Data[max] < Pivot)
		{
			swap(Data[min], Data[max]);
			min++;
			max--;
		}
		else if (Data[min]>Pivot && Data[max]>Pivot)
		{
			max--;
		}
		else if (Data[min]<Pivot && Data[max]<Pivot)
		{
			min++;
		}
		else
		{
			min++;
			max--;
		}

	}

	if (Data[min] > Pivot)
	{
		swap(Data[min], Data[end]);
	}

	return min;
}

void QuickSort(int* Data, int begin, int end)
{
	if (begin < end)
	{
		//�ڷ� ������
		int Pivot = Partition(Data, begin, end);
		for (size_t k = 0; k < 10; k++)
		{
			cout << Data[k] << ", ";
		}
		cout << endl << "Pivot : " << Pivot << endl;
		QuickSort(Data, begin, Pivot - 1);
		QuickSort(Data, Pivot + 1, end);
	}
}



bool cmp(int a, int b)
{
	return a > b;
}

void test(int a, int b)
{
	cout << a + b << endl;
}
int main()
{
	////UE4 Delegate UE4
	////�Լ�������
	//void(*fp)(int, int);
	////ex) void test(int a, int b);
	//fp = test;
	//fp(1, 2);

	int Data[] = {5, 4, 6, 7, 8, 9 ,10, 3,2,1};
	//��������
	//BubbleSort(Data, 5);

	//��������
	//SelectionSort(Data, 5, cmp);

	//algorithm Ŭ���� ���
	//sort(Data, Data + 5, greater<int>());

	//������
	QuickSort(Data, 0, 9);

	//��������


	for (auto i : Data)
	{
		cout << i << ", ";
	}
	return 0;
}