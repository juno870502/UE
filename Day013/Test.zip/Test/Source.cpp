#include <iostream>
#include <Windows.h>
#include <queue>

using namespace std;

#define MAX 10

int Array1[MAX][MAX] = {
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 1, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 1, 1, 1, 0, 0, 0},
	{0, 0, 0, 0, 1, 1, 1, 1, 0, 0},
	{0, 0, 0, 0, 1, 1, 1, 1, 1, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 1, 1, 0, 0, 0, 0, 0, 0, 0},
	{0, 1, 1, 1, 1, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

int Array2[MAX][MAX] = {
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 1, 1, 1, 0, 0, 0, 0, 0},
	{0, 0, 1, 0, 1, 0, 0, 0, 0, 0},
	{0, 0, 1, 0, 1, 1, 1, 1, 0, 0},
	{0, 0, 1, 0, 0, 0, 0, 1, 0, 0},
	{0, 0, 1, 1, 1, 1, 1, 1, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 1, 1, 0, 0, 0, 0, 0, 0, 0},
	{0, 1, 1, 1, 1, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

int Array3[MAX][MAX] = {
	{5, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 5, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 5, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};

struct Point
{
	Point(int _x = 0, int _y = 0) { x = _x; y = _y; }
	int x;
	int y;
};

void PrintArray(const int Array[MAX][MAX])
{
	for (size_t y = 0; y < MAX; y++)
	{
		for (size_t x = 0; x < MAX; x++)
		{
			cout << Array[y][x] << "\t";
		}
		cout << endl;
	}
}
int RCountOne(Point Current)
{
	if (Current.x < 0 || Current.x >= MAX || Current.y < 0 || Current.y >= MAX)
	{
		return 0;
	}
	else if (Array1[Current.y][Current.x] == 0 || Array1[Current.y][Current.x] == 2)
	{
		return 0;
	}

	if (Array1[Current.y][Current.x] == 1)
	{
		Array1[Current.y][Current.x] = 2;
	}

	Point UP(Current.x, Current.y - 1);
	Point RIGHT(Current.x + 1, Current.y);
	Point DOWN(Current.x, Current.y + 1);
	Point LEFT(Current.x - 1, Current.y);
	return(1 + RCountOne(UP) +
		RCountOne(RIGHT) +
		RCountOne(LEFT) +
		RCountOne(DOWN));
}

void RColoring(Point Current)
{
	if (Current.x < 0 || Current.x >= MAX || Current.y < 0 || Current.y >= MAX)
	{
		return;
	}
	else if (Array2[Current.y][Current.x] == 1)
	{
		return;
	}

	Array2[Current.y][Current.x] = 1;

	Point UP(Current.x, Current.y - 1);
	RColoring(UP);
	Point RIGHT(Current.x + 1, Current.y);
	RColoring(RIGHT);
	Point DOWN(Current.x, Current.y + 1);
	RColoring(DOWN);
	Point LEFT(Current.x - 1, Current.y);
	RColoring(LEFT);
}

int DistanceFunc(Point a, Point b)
{
	int x = b.x - a.x;
	int y = b.y - a.y;
	int distance = x * x + y * y;
	return distance;
}

void PutPixel(int x, int y)
{
	COORD c;
	c.X = x;
	c.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
	printf("#");
}

void RLine(int StartX, int StartY, int EndX, int EndY)
{
	if (abs(EndX - StartX) <= 1 && abs(EndY - StartY) <= 1)
	{
		PutPixel(StartX, StartY);
		PutPixel(EndX, EndY);
		return;
	}
	else
	{
		PutPixel((StartX + EndX) / 2, (StartY + EndY) / 2);
		RLine(StartX, StartY, (StartX + EndX) / 2, (StartY + EndY) / 2);
		RLine((StartX + EndX) / 2, (StartY + EndY) / 2, EndX, EndY);
	}
}

int main()
{
	//Point Start1(8,5);
	//cout << "Num of One : " << RCountOne(Start1) << endl;
	//PrintArray(Array1);

	//Point Start2(5, 4);
	//RColoring(Start2);
	//PrintArray(Array2);

	Point Start3(0, 0);
	Point End(0, 3);
	RLine(0, 0, 100, 2);
}