#include <iostream>
#include <Windows.h>
#include "Player.h"
#include "Map.h"

Player::Player()
{
	Init();
}


Player::~Player()
{
}

void Player::Init()
{
	Character::Init();
	X = 1;
	Y = 1;
	job = EJob::Farmer;
}

void Player::Draw()
{
	//__super::Draw();
	Character::Draw();	//�θ�Ŭ���� �Լ� ����

	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 13);	//���ֻ�
	std::cout << "P";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 7);	//�⺻��
}

int Player::getPlayerX()
{
	return X;
}

int Player::getPlayerY()
{
	return Y;
}
