#pragma once

enum class EJob
{
	Farmer = 1,
	Fishman,
	Engineer
};
