#include "Character.h"
#include "Map.h"
#include <Windows.h>
#include <iostream>

Character::Character()
{
}


Character::~Character()
{
}

void Character::Move(Map * map, int KeyCode)
{
	if (KeyCode == UP)
	{
		if (!map->IsUpWall(X, Y))
		{
			--Y;
		}
	}
	else if (KeyCode == DOWN)
	{
		if (!map->IsDownWall(X, Y))
		{
			++Y;
		}
	}
	else if (KeyCode == LEFT)
	{
		if (!map->IsLeftWall(X, Y))
		{
			--X;
		}
	}
	else if (KeyCode == RIGHT)
	{
		if (!map->IsRightWall(X, Y))
		{
			++X;
		}
	}
}

void Character::Draw()
{
	COORD c;
	c.X = X;
	c.Y = Y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);	//�÷��̾� ��ǥ�� Ŀ�� ��ġ ����
}

void Character::Init()
{
}
