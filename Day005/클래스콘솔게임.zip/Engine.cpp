#include <conio.h>
#include <iostream>
#include <Windows.h>
#include "Engine.h"
#include "Map.h"
#include "Player.h"
#include "Goal.h"
#include "Monster.h"

using namespace std;

Engine::Engine()
{
	cout << "Engine Constructor" << endl;
	bIsRunning = true;
	map = new Map();
	player = new Player();
	goal = new Goal();
	monster = new Monster();
	InitGoalPosition();
	InitMonstersPosition();
}


Engine::~Engine()		//����� ������ ������ �ݴ��!
{
	delete monster;
	delete goal;
	delete player;
	delete map;
	monster = nullptr;
	goal = nullptr;
	player = nullptr;
	map = nullptr;
	cout << "Engine Destructor" << endl;
}

void Engine::Run()
{
	while (bIsRunning)
	{
		int keyCode = Input();
		Process(keyCode);
		Render();
	}
}

int Engine::Input()
{
	return _getch();
}

void Engine::Process(int keyCode)
{
	//�ɸ��� �̵�
	player->Move(map, keyCode);
	monster->Move(map);
	//monster->Move(player->getPlayerX(), player->getPlayerY(), map);

	//����
	IsComplete();
	IsQuit(keyCode);
	IsFail();
}

void Engine::Render()
{
	system("cls");
	//cout << "Rendering" << endl;
	map->Draw();
	player->Draw();
	goal->Draw();
	monster->Draw();
}

void Engine::InitGoalPosition()
{
	for (size_t y = 0; y < map->sizeX; y++)
	{
		for (size_t x = 0; x < map->sizeY; x++)
		{
			if (map->map[y][x] == '3')
			{
				goal->X = x;
				goal->Y = y;
			}
		}
	}
}

void Engine::InitMonstersPosition()
{
	for (size_t y = 0; y < map->sizeX; y++)
	{
		for (size_t x = 0; x < map->sizeY; x++)
		{
			if (map->map[y][x] == '5')
			{
				monster->X = x;
				monster->Y = y;
			}
		}
	}
}

void Engine::IsQuit(int keyCode)
{
	if (keyCode == 'q' || keyCode == 'Q')
	{
		bIsRunning = false;
	}
}

void Engine::IsComplete()
{
	//����
	if (player->getPlayerX() == goal->X && player->getPlayerY() == goal->Y)
	{
		//�¸�ȭ�� ���
		bIsRunning = false;
	}
}

void Engine::IsFail()
{
	if (player->getPlayerX() == monster->X && player->getPlayerY() == monster->Y)
	{
		bIsRunning = false;
	}
}

void Engine::StopEngine()
{
	bIsRunning = false;
}
