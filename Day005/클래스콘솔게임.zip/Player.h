#pragma once
#include "Job.h"
#include "Character.h"

class Player : public Character
{
public:
	Player();
	~Player();

	
	virtual void Init() override;
	
	virtual void Draw() override;

	int getPlayerX();
	int getPlayerY();

private:
	EJob job;
	
	//int X;
	//int Y;
};

