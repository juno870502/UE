#include <stdlib.h>
#include <Windows.h>
#include <iostream>
#include "Monster.h"
#include "Map.h"


Monster::Monster()
{
}


Monster::~Monster()
{
}


void Monster::Move(Map * map, int KeyCode)
{
	int dir = rand() % 4;
	switch (dir)
	{
	case 0:
		KeyCode = UP;
		break;
	case 1:
		KeyCode = DOWN;
		break;
	case 2:
		KeyCode = LEFT;
		break;
	case 3:
		KeyCode = RIGHT;
		break;
	default:
		break;
	}
	Character::Move(map, KeyCode);
}

//void Monster::Move(int playerX, int playerY, Map * map)
//{
//	int decision = rand() % 2;
//	if (decision == 0)
//	{
//		Move(map);
//	}
//	else
//	{
//		if (X - playerX > Y - playerY)
//		{
//			if (X < playerX)
//			{
//				if (!map->IsRightWall(X, Y))
//				{
//					X++;
//				}
//			}
//			else
//			{
//				if (!map->IsLeftWall(X, Y))
//				{
//					X--;
//				}
//			}
//		}
//		else
//		{
//			if (Y < playerY)
//			{
//				if (!map->IsDownWall(X, Y))
//				{
//					Y++;
//				}
//			}
//			else
//			{
//				if (!map->IsUpWall(X, Y))
//				{
//					Y--;
//				}
//			}
//		}
//	}
//}

void Monster::Draw()
{
	//__super::Draw();
	Character::Draw();	//�θ�Ŭ���� draw ����

	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 5);	//���ֻ�
	std::cout << "M";
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 7);	//�⺻��
}
