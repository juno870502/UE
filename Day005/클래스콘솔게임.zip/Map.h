#pragma once
#include <string>
#include "Player.h"

class Map
{
public:
	Map();
	~Map();

	void Draw();

	bool IsUpWall(int x, int y);
	bool IsDownWall(int x, int y);
	bool IsLeftWall(int x, int y);
	bool IsRightWall(int x, int y);

	void InitMap();
	
	int sizeX;
	int sizeY;

	std::string map[20];	//2�߹迭 ���� ������ �ȵ�.. ���� string ��

private:

	std::string name;

	
};

