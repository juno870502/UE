#pragma once
class Goal
{
public:
	Goal();
	~Goal();

	int X;
	int Y;

	void Draw();
};

