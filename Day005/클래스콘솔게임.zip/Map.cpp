#include <iostream>
#include <fstream>
#include <Windows.h>

#include "Map.h"


Map::Map()
{
	std::cout << "Map Constructor" << std::endl;
	sizeX = 20;
	sizeY = 20;
	InitMap();
}


Map::~Map()
{
	std::cout << "Map Destructor" << std::endl;
}

void Map::Draw()
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);	//���
	for (size_t y = 0; y < sizeX; y++)
	{
		for (size_t x = 0; x < sizeY; x++)
		{
			if (map[y][x] == '1')
			{
				std::cout << map[y][x];
			}
			else
			{
				std::cout << " ";
			}
		}
		std::cout << std::endl;
	}
	
}


bool Map::IsUpWall(int x, int y)
{
	if (map[y-1][x] == '1')
	{
		return true;
	}
	else
		return false;
}

bool Map::IsDownWall(int x, int y)
{
	if (map[y+1][x] == '1')
	{
		return true;
	}
	else
		return false;
}

bool Map::IsLeftWall(int x, int y)
{
	if (map[y][x-1] == '1')
	{
		return true;
	}
	else
		return false;
}

bool Map::IsRightWall(int x, int y)
{
	if (map[y][x+1] == '1')
	{
		return true;
	}
	else
		return false;
}

void Map::InitMap()
{
	FILE* fp;
	fp = fopen("c:/Data/map.txt", "r");

	//���� ��Ʈ������ �� ���� �ҷ�����
	std::ifstream fin("map.txt");
	
	for (size_t i = 0; i < sizeY; i++)
	{
		std::getline(fin, map[i]);
	}
	
	
	/*map[0] = "1111111111";
	map[1] = "1010000131";
	map[2] = "1010010101";
	map[3] = "1010010101";
	map[4] = "1010100101";
	map[5] = "1010100101";
	map[6] = "1010101001";
	map[7] = "1010101001";
	map[8] = "1000100001";
	map[9] = "1111111111";*/
}
