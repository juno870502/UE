#pragma once

class Engine
{
public:
	Engine();
	~Engine();

	void Run();

	class Map* map;
	class Player* player;
	class Goal* goal;
	class Monster* monster;

private:
	bool bIsRunning;

	int Input();
	void Process(int keyCode);
	void Render();
	void InitGoalPosition();
	void InitMonstersPosition();

	void IsQuit(int keyCode);
	void IsComplete();
	void IsFail();
	
	void StopEngine();


};

