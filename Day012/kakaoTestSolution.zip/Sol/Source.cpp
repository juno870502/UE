#include <iostream>
#include <bitset>
#include <string>

using namespace std;

string* findmap(int n, int* arr1, int* arr2)
{
	int* arr3 = new int[n];
	string* result = new string[n];

	for (size_t i = 0; i < n; i++)
	{
		arr3[i] = arr1[i] | arr2[i];

		result[i] = bitset<16>(arr3[i]).to_string();
		result[i] = result[i].substr(16 - n, n);
		for (size_t len = 0; len < result[i].length(); len++)
		{
			result[i][len] = result[i][len] == '1' ? '#' : ' ';
		}
	}
	return result;
}

int main()
{
	int n = 5;
	int arr1[] = { 9, 20, 28, 18, 11 };
	int arr2[] = { 30, 1, 21, 17, 28 };

	string* result = findmap(n, arr1, arr2);

	for (size_t i = 0; i < n; i++)
	{
		cout << result[i] << endl;
	}
	
	return 0;
}
