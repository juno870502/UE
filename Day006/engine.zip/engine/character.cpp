#include "character.h"
#include <iostream>

using namespace std;


character::character()
{
	cout << "ĳ���� ����" << endl;
}


character::~character()
{
	cout << "ĳ���� ����" << endl;
}

void character::Tick()
{
	cout << "character Update..." << endl;
}

void character::Move()
{
	cout << "character Move..." << endl;
}

void character::Draw()
{
	cout << "character Draw..." << endl;
}

void character::SetName(std::string newName)
{
	cout << "ĳ���� �̸� ����" << endl;
	name = newName;
}

std::string character::GetName()
{
	return name;
}
