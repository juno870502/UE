#pragma once
#include "character.h"
class Monster : public character
{
public:
	Monster();
	virtual ~Monster();

	void GiveItem();
};

