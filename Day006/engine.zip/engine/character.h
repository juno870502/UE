#pragma once
#include <string>
#include "Object.h"
class character : public Object
{
public:
	character();
	virtual ~character();

	virtual void Tick();
	virtual void Draw();

	//accessor, ������.
	void SetName(std::string newName);
	std::string GetName();

protected:
	std::string name;
	virtual void Move();
};

