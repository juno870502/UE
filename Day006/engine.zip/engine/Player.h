#pragma once
#include "character.h"
class Player : public character
{
public:
	Player();
	~Player();

	virtual void Input();
	virtual void Tick();
	virtual void Draw();

protected:

	void Skill1();
};

