#pragma once
#include "Player.h"
#include "Slime.h"
#include "Goblin.h"
#include "character.h"
#include <vector>

class Engine
{
public:
	Engine();
	~Engine();

	void Run();

	void IsQuit();

protected:

	int Input();
	void Tick(int keyInput);
	void Render();

	//has a ����
	//class Player* player;
	//class Goblin* goblin;
	//class Slime* slime;

	bool bIsRunning;
	int TotalCharacterCount;


	std::vector<character*> vCharacters;
};

