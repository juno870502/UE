#pragma once
#include "Monster.h"
class Slime : public Monster
{
public:
	Slime();
	~Slime();

	virtual void Tick();
	virtual void Draw();
};

