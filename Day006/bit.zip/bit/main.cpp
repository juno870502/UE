#include <bitset>
#include <iostream>
#include <conio.h>

using namespace std;
typedef unsigned char byte;

int clamp(int x, int min, int max);

//��Ʈ ����ũ �ɼ� ����� ex ���Ľ�
#define O1 0x01	//0000 0001, 1
#define O2 0x02	//0000 0010, 2
#define O3 0x04	//0000 0100, 4
#define O4 0x08	//0000 1000, 8
#define O5 0x10	//0001 0000, 16
#define O6 0x20	//0010 0000, 32
#define O7 0x40	//0100 0000, 64
#define O8 0x80	//1000 0000, 128
//�Ǵ�
#define O1 1<<0	//0000 0001, 1
#define O2 1<<1	//0000 0010, 2
#define O3 1<<2	//0000 0100, 4
#define O4 1<<3	//0000 1000, 8
#define O5 1<<4	//0001 0000, 16
#define O6 1<<5	//0010 0000, 32
#define O7 1<<6	//0100 0000, 64
#define O8 1<<7	//1000 0000, 128

int main()
{
	byte option = O1 | O2 | O5;
	if (option & (O2 | O4))
	{
		cout << "true" << endl;
	}
	else
	{
		cout << "false" << endl;
	}
	cout << bitset<8>(option) << endl;
	return 0;
}