#include <bitset>
#include <iostream>
#include <conio.h>

#define RIGHT 39
#define LEFT 37

using namespace std;
typedef unsigned char byte;

int clamp(int x, int min, int max);


int main()
{
	byte a = 0x01;	//�� ���
	char i = 0;

	byte b = 0x01;	//�� ���
	int pos = 0;

	bool bIsRunning = true;
	while (bIsRunning)
	{
		i = getch();
		switch (i)
		{
		case 'a':
		case LEFT:
			if (a < 127)
			{
				a = a << 1;
			}
			pos++;
			//cout << bitset<8>(a) << endl;
			break;
		case 'd':
		case RIGHT:
			if (a > 1)
			{
				a = a >> 1;
			}
			pos--;
			//cout << bitset<8>(a) << endl;
			break;
		case 'q':
		case 'Q':
			bIsRunning = false;
			break;
		default:
			break;
		}

		//�� �ƽ� �� ������ (clamp);
		/*if (pos < 0)
		{
			pos = 0;
		}
		if (pos > 7)
		{
			pos = 7;
		}*/
		pos = clamp(pos, 0, 7);
		cout << bitset<8>(b << pos) << endl;
	}
	return 0;
}

int clamp(int x, int min, int max)
{
	if (x < min)
	{
		x = min;
	}
	else if (x > max)
	{
		x = max;
	}
	else
	{
		x;
	}
	return x;
}
