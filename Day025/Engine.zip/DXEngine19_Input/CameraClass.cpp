#include "CameraClass.h"



CameraClass::CameraClass()
{
	fovY = 75.0f * Deg2Rad;
	nearZ = 1.0f;
	farZ = 1000.0f;
}


CameraClass::~CameraClass()
{
}

void CameraClass::SetFovY(float fovY)
{
	this->fovY = fovY * Deg2Rad;
	UpdateProjectionMatrix();
}

void CameraClass::SetAspectRatio(UINT width, UINT height)
{
	this->aspectRatio = (float)width / (float)height;
	
}

void CameraClass::GetPlaneDistance(float & zN, float & zF)
{
	zN = nearZ;
	zF = farZ;
}

void CameraClass::SetPlaneDistance(float zN, float zF)
{
	nearZ = zN;
	farZ = zF;
}

void CameraClass::SetPosition(XMVECTOR pos)
{
	cameraPosition = pos;
	UpdateViewMatrix();
}

void CameraClass::MoveFoward(float direction)
{
	cameraPosition += direction * moveSpeed * cameraForward;
}

void CameraClass::MoveRight(float direction)
{
	cameraPosition += direction * moveSpeed * cameraRight;
}

void CameraClass::MoveUp(float direction)
{
	cameraPosition += direction * moveSpeed * cameraUp;
}

void CameraClass::Yaw(float angle)
{
	yaw += angle * rotationSpeed * 0.001f;
}

void CameraClass::Pitch(float angle)
{
	pitch += angle * rotationSpeed * 0.001f;
}

void CameraClass::Roll(float angle)
{
	roll += angle * rotationSpeed * 0.001f;
}

void CameraClass::UpdateCamera()
{
	XMMATRIX rotMatrix = XMMatrixRotationRollPitchYaw(pitch, yaw, roll);
	cameraLook = XMVector3TransformCoord(defaultForward, rotMatrix);
	cameraLook = XMVector3Normalize(cameraLook);

	XMMATRIX rotYTemp = XMMatrixRotationY(yaw);
	XMMATRIX rotXTemp = XMMatrixRotationY(pitch);
	XMMATRIX rotZTemp = XMMatrixRotationY(roll);

	//cameraRight = XMVector3TransformCoord(defaultRight, rotYTemp);
	//cameraForward = XMVector3TransformCoord(defaultForward, rotZTemp);
	//cameraUp = XMVector3TransformCoord(defaultUp, rotXTemp);

	cameraRight = XMVector3TransformCoord(defaultRight, rotMatrix);
	cameraForward = XMVector3TransformCoord(defaultForward, rotMatrix);
	cameraUp = XMVector3TransformCoord(defaultUp, rotMatrix);

	cameraLook = cameraPosition + cameraLook;

	UpdateViewMatrix();
}

void CameraClass::UpdateViewMatrix()
{
	viewMatrix = XMMatrixLookAtLH(cameraPosition, cameraLook, cameraUp);
}

void CameraClass::UpdateProjectionMatrix()
{
	projectionMatrix = XMMatrixPerspectiveFovLH(fovY, aspectRatio, nearZ, farZ);
}
