#pragma once
#include "D3DApp.h"
class InitDirect3DApp :
	public D3DApp
{
public:
	InitDirect3DApp(HINSTANCE hInstance);
	~InitDirect3DApp();

	virtual bool Initialize();

private:
	virtual void OnResize();
	virtual void Update(const GameTimer& gt)override;
	virtual void Draw(const GameTimer& gt)override;

};

