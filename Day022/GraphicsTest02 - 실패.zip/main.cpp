#include "InitDirect3DApp.h"

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE prevInstance,
	LPSTR lpCmdLine, int nCmdLine)
{
	InitDirect3DApp app(hInstance);
	if (app.Initialize() == false)
	{
		return 0;
	}

	return app.Run();
}