#include "InitDirect3DApp.h"



InitDirect3DApp::InitDirect3DApp(HINSTANCE hInstance)
	:D3DApp(hInstance)
{

}


InitDirect3DApp::~InitDirect3DApp()
{
}

bool InitDirect3DApp::Initialize()
{
	if (!D3DApp::Initialize())
	{
		return false;
	}
	return true;
}

void InitDirect3DApp::OnResize()
{
}

void InitDirect3DApp::Update(const GameTimer & gt)
{
}

void InitDirect3DApp::Draw(const GameTimer & gt)
{
	// ���� ����.
	float color[4] = { 0.0f, 0.5f, 0.5f, 1.0f };

	// ȭ�� ĥ�ϱ�.
	pDeviceContext->ClearRenderTargetView(pRenderTargetView, color);

	// ���� �׸���.
	pDeviceContext->Draw(3, 0);

	// ����ü�� ��ü.
	pSwapChain->Present(0, 0);
}
