#include "D3DApp.h"

D3DApp* mApp = NULL;

LRESULT CALLBACK WinProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (mApp != NULL)
	{
		mApp->MsgProc(hwnd, msg, wParam, lParam);
	}
	else
	{
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}
}

D3DApp::D3DApp(HINSTANCE hInstance)
{
	mhAppInst = hInstance;
	mApp = this;
}


D3DApp::~D3DApp()
{
}

HWND D3DApp::MainWnd() const
{
	return mhMainWnd;
}

float D3DApp::AspectRatio() const
{
	return static_cast<float>(mClientWidth) / mClientHeight;
}

bool D3DApp::InitMainWindow()
{
	WNDCLASSEX wc;
	ZeroMemory(&wc, sizeof(WNDCLASSEX));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.hInstance = mhAppInst;
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = NULL;
	wc.lpszClassName = L"WindowClass";
	wc.lpfnWndProc = WinProc;

	if (!RegisterClassEx(&wc))
	{
		return false;
	}

	mhMainWnd = CreateWindow(L"WindowClass", L"DirectX ���� ù��°",
		WS_OVERLAPPEDWINDOW, 0, 0, mClientWidth, mClientHeight, NULL, NULL,
		mhAppInst, NULL);

	if (mhMainWnd == NULL)
	{
		return false;
	}

	ShowWindow(mhMainWnd, SW_SHOW);
	return true;
}

int D3DApp::Run()
{
	MSG msg;
	ZeroMemory(&msg, sizeof(msg));
	while (msg.message != WM_QUIT)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			Update(mTimer);
			Draw(mTimer);
		}
	}
	return 0;
}

bool D3DApp::Initialize()
{
	if (InitMainWindow() == false)
	{
		return false;
	}
	//InitDirect3D();
	return true;
}

LRESULT D3DApp::MsgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_KEYDOWN:
	{
		if (wParam == VK_ESCAPE)
		{
			DestroyWindow(hwnd);
		}
		return 0;
	}
	case WM_DESTROY:
	{
		PostQuitMessage(0);
		return 0;
	}
	default:
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}
}
