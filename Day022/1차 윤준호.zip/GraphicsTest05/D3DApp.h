#pragma once
#include <Windows.h>
#include <xnamath.h>
#include <d3d11.h>
#include <d3dx11.h>

#include "GameTimer.h"

#pragma comment (lib, "d3d11.lib")
#pragma comment (lib, "d3dx11.lib")

class D3DApp
{
public:
	// ���� ����.
	struct Vertex
	{
		float x;
		float y;
		float z;

		Vertex(float x, float y, float z) : x(x), y(y), z(z) { }
	};

	//��� ���ۿ� ����ü
	struct CBPerObject
	{
		XMMATRIX world;
	};

protected:
	D3DApp(HINSTANCE hInstance);
	D3DApp(const D3DApp& rhs) = delete;
	D3DApp& operator==(const D3DApp& rhs) = delete;
	virtual ~D3DApp();

public:
	//static D3DApp* GetApp();
	//HINSTANCE AppInst()const;
	HWND MainWnd()const;
	float AspectRatio()const;

	//bool Get4xMsaaState()const;
	//void Set4xMsaaState(bool value);

	int Run();

	virtual bool Initialize();
	virtual LRESULT MsgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

protected:
	//virtual void CreateRtvAndDsvDescriptorHeaps();
	//virtual void OnResize();
	virtual void Update(const GameTimer& gt)=0;
	virtual void Draw(const GameTimer& gt)=0;

	virtual void OnMouseDown(WPARAM btnState, int x, int y) {}
	virtual void onMouseUp(WPARAM btnState, int x, int y) {}
	virtual void onMouseMove(WPARAM btnState, int x, int y) {}

protected:
	bool InitMainWindow();
	bool InitDirect3D();
	bool InitScene();
	bool InitTransformation();

protected:
	//static D3DApp* GetApp();

	HINSTANCE mhAppInst = nullptr;
	HWND	mhMainWnd = nullptr;
	//bool	mAppPaused = false;
	//bool	mMinimized = false;
	//bool	mMaximized = false;
	//bool	mResizing = false;
	//bool	mFullscreenState = false;

	//bool m4xMsaaState = false;
	//UINT m4xMsaaQuality = 0;

	GameTimer mTimer;

	// DirectX ����.
	ID3D11Device* pDevice;
	ID3D11DeviceContext* pDeviceContext;
	IDXGISwapChain* pSwapChain;
	ID3D11RenderTargetView* pRenderTargetView;

	ID3D11Buffer* vertexBuffer;		// ���� ����.
	ID3D11VertexShader* vertexShader;		// ���� ���̴�.
	ID3D11PixelShader* pixelShader;			// �ȼ� ���̴�.
	ID3DBlob* vertexShaderBuffer;		// ���� ���̴� ����.
	ID3DBlob* pixelShaderBuffer;		// �ȼ� ���̴� ����.
	ID3D11InputLayout* vertexInputLayout;	// �Է� ���̾ƿ�.

	//������ȯ�� �ʿ��� ���� ����
	XMMATRIX worldMatrix;		//���� ��ȯ ���

	ID3D11Buffer* cBuffer;		//�������
	
	int mClientWidth = 800;
	int mClientHeight = 600;
	
};

