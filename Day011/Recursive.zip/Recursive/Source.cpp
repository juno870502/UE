#include <iostream>
#include <string>
#include <stack>
using namespace std;

int SumRe(int n)
{
	if (n == 1)
	{
		return n;
	}
	return n + SumRe(n - 1);
}
int Sum(int n)
{
	int temp = 0;
	for (int i = 1; i <= n; i++)
	{
		temp += i;
	}
	return temp;
}
void ReversePrint(string msg)
{
	for (int i = msg.length()-1; i >= 0; --i)
	{
		cout << msg.substr(i, 1);
	}
	cout << endl;
}

void ReversePrintRe(string msg)
{
	if (msg.length() == 0)
	{
		return;
	}
	ReversePrintRe(msg.substr(1));
	cout << msg.substr(0,1);
}

int ArraySum(int* Num, int Size)
{
	int Sum = 0;
	for (size_t i = 0; i < Size; i++)
	{
		Sum += Num[i];
	}
	return Sum;
}

int RArraySum(int* Num, int Size)
{
	if (Size == 0)
	{
		return 0;
	}
	return Num[Size - 1] + RArraySum(Num, Size - 1);
}

int StringLength(char* str)
{
	for ( int i = 0; ; ++i)
	{
		if (str[i] == '\0')
		{
			return i;
		}
	}
}

int RStringLength(char* str)
{
	if (str[0] == '\0')
	{
		return 0;
	}
	return 1 + RStringLength(str + 1);
}

void ToBinary(int n)
{
	//int temp = n;
	//int binary = 0;
	//int loc = 1;
	//while (temp > 0)
	//{
	//	binary = binary + (temp % 2) * loc;
	//	temp = temp / 2;
	//	loc = loc * 10;
	//}
	//cout << binary << endl;
	stack<int> Binary;
	while (n >= 1)
	{
		int mod = n % 2;
		n = n / 2;
		Binary.push(mod);
	}
	while (!Binary.empty())
	{
		cout << Binary.top();
		Binary.pop();
	}
}

void RToBinary(int n)
{
	if (n <= 0)
	{
		return;
	}
	RToBinary(n / 2);
	cout << n % 2;
}

int Factorial(int n)
{
	int sum = 1;
	for (size_t i = 1; i <= n; i++)
	{
		sum *= i;
	}
	return sum;
}

int RFactorial(int n)
{
	if (n <= 1)
	{
		return n;
	}
	return n * RFactorial(n - 1);
}

static int SearchTime = 0;

int Search(int* Data, int Size, int Target)
{
	for (size_t i = 0; i < Size; i++)
	{
		if (Target == Data[i])
		{
			return i;
		}
	}
	return -1;
}

int RSearch(int* Data, int Size, int Target)
{
	if (Size <= 0)
	{
		return -1;
	}
	if (Data[Size - 1] == Target)
	{
		return Size - 1;
	}
	return RSearch(Data, Size - 1, Target);
}

int RSearch2(int* Data, int begin, int end, int target)
{
	SearchTime++;
	if (begin > end)
	{
		return -1;
	}
	else if(Data[begin] == target)
	{
		return begin;
	}
	else
	{
		RSearch2(Data, begin + 1, end, target);
	}
}

int RSearch3(int* Data, int begin, int end, int target)
{
	SearchTime++;
	if (begin > end)
	{
		return -1;
	}
	else
	{
		int middle = (begin + end) / 2;
		if (Data[middle] == target)
		{
			return middle;
		}
		else if (Data[middle] > target)
		{
			return RSearch3(Data, begin, middle - 1, target);
		}
		else
		{
			return RSearch3(Data, middle + 1, end, target);
		}
	}
}
int main()
{
	//cout << Sum(10) << endl;
	//cout << SumRe(10) << endl;

	//string str = "HelloWorld";

	//ReversePrint(str);
	//ReversePrintRe(str);

	//int num[5] = { 1,2,3,4,5 };
	//cout << ArraySum(num, 5) << endl;;
	//cout << RArraySum(num, 5) << endl;;
	

	//char str2[] = "Hello";
	//cout << StringLength(str2) << endl;
	//cout << RStringLength(str2) << endl;

	//ToBinary(255);
	//cout << endl;
	//RToBinary(255);

	//cout << Factorial(5) << endl;
	//cout << RFactorial(5) << endl;

	int Data[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	//cout << Search(Data, 10, 3) << endl;
	//cout << RSearch(Data, 10, 30) << endl;
	//cout << RSearch2(Data, 0, 9, 3) << endl;
	cout << RSearch3(Data, 0, 9, 8) << endl;
	cout << "Ž�� ȸ�� : " << SearchTime << endl;

	return 0;
}