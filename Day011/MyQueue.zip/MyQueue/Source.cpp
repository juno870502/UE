#include "MyQueue.h"
#include <iostream>
using namespace std;

int main()
{
	MyQueue<int> MQ(5);
	//MQ.Enqueue(1);
	//MQ.Enqueue(2);
	//MQ.Enqueue(3);

	for (size_t i = 1; i <= 5; i++)
	{
		MQ.Enqueue(i);
	}

	for (size_t i = 1; i <= 5; i++)
	{
		cout << MQ.Dequeue() << endl;
	}

	MyQueue<float> FQ(5);

	for (float i = 1; i <= 5; i++)
	{
		FQ.Enqueue(i*0.3f);
	}
	for (size_t i = 1; i <= 5; i++)
	{
		cout << FQ.Dequeue() << endl;
	}
}
