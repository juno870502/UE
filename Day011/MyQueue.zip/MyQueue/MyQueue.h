#pragma once
template<class T>
class MyQueue
{
public:
	MyQueue(int InitCapacity = 10);
	~MyQueue();

	void Enqueue(T Value);
	T Dequeue();

	bool IsFull();
	bool IsEmpty();

	class Iterator
	{
	public:
		Iterator(MyQueue<T>* InitQ = nullptr) { this = InitQ; }
		~Iterator (){}

		bool operator!=(const Iterator& rhs) { return !rhs.MyQ->IsEmpty(); }
		T& operator*() { return this->MyQ->Dequeue(); }
		Iterator& operator++() {}//�߰��ʿ�
	protected:
		MyQueue<T>* MyQ;
		int Index;
	};

	Iterator begin() {}
	Iterator end() {}

	static T Empty;

protected:
	int TotalSize;
	int CurrentSize;
	T* Data;
	int Head;
	int Tail;
};

template<class T>
inline MyQueue<T>::MyQueue(int InitCapacity)
{
	TotalSize = InitCapacity;
	CurrentSize = 0;
	Data = new T[TotalSize];
	Head = 0;
	Tail = 0;
}

template<class T>
inline MyQueue<T>::~MyQueue()
{
	delete[] Data;
}

template<class T>
inline void MyQueue<T>::Enqueue(T Value)
{
	if (IsFull())
	{
		return;
	}
	Data[Head] = Value;
	CurrentSize++;
	Head++;
	Head = Head % TotalSize;
}

template<class T>
inline T MyQueue<T>::Dequeue()
{
	if (IsEmpty())
	{
		return Empty;
	}
	T Temp = Data[Tail];
	Tail++;
	Tail = Tail % TotalSize;
	CurrentSize--;
	return Temp;
}

template<class T>
inline bool MyQueue<T>::IsFull()
{
	//�� á����
	if (CurrentSize < TotalSize)
	{
		return false;
	}
	return true;
}

template<class T>
inline bool MyQueue<T>::IsEmpty()
{
	if (CurrentSize == 0)
	{
		return true;
	}
	return false;
}

template<class T>
T MyQueue<T>::Empty;