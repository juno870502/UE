#pragma once
template<class T>
class MyVector
{
protected:
	T* DataArray;
	int Capacity;
	int Size;

public:
	MyVector();
	~MyVector();

	//����
	bool Insert(T Value);

	//����(�ε����� ����)
	bool Delete(int Index);

	//�ε��� -> ��
	T& ReturnValueByIndex(int Index);

	//�� -> �ε���
	int ReturnIndexByValue(T Value);

	//��������
	bool Resize();

	//���۷�����
	T operator[](int Index);

	//���ͷ�����
	class Iterator
	{
	protected:
		int Index;
		MyVector<T>* V;

	public:
		Iterator(MyVector<T>* Vec = nullptr, int Size = 0) { V = Vec; Index = Size; }
		bool operator!=(const Iterator& rhs) { return (this->Index != rhs.Index); }
		Iterator& operator++() { Index++; return *this; }
		T& operator*() { return V->ReturnValueByIndex(Index); }
	};

	Iterator begin() { return Iterator(this); }
	Iterator end() { return Iterator(this, Capacity-1); }
};

template<typename T>
inline MyVector<T>::MyVector()
{
	Capacity = 10;
	DataArray = new T[Capacity];
	Size = 0;
}

template<typename T>
inline MyVector<T>::~MyVector()
{
	delete[] DataArray;
}

template<typename T>
inline bool MyVector<T>::Insert(T Value)
{
	if (Size < Capacity)
	{
		DataArray[Size] = Value;
		Size++;
		return true;
	}
	return false;
}

template<typename T>
inline bool MyVector<T>::Delete(int Index)
{
	if (Index >= Capacity || Index < 0)
	{
		return false;
	}
	memcpy(&DataArray[Index], &DataArray[Index + 1], sizeof(T) * (Size - Index - 1));
	return true;
}

template<typename T>
inline T& MyVector<T>::ReturnValueByIndex(int Index)
{
	return DataArray[Index];
}

template<typename T>
inline int MyVector<T>::ReturnIndexByValue(T Value)
{
	return 0;
}

template<typename T>
inline bool MyVector<T>::Resize()
{
	Capacity = Capacity << 1;
	T* TempArray = new T[Capacity];
	if (TempArray == nullptr)
	{
		return false;
	}
	memcpy(TempArray, DataArray, Size);
	DataArray = TempArray;
	return true;
}

template<class T>
inline T MyVector<T>::operator[](int Index)
{
	return DataArray[Index];
}
