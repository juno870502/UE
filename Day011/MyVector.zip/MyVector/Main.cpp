#include "MyVector.h"
#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	MyVector<int> MyIntVector;
	for (size_t i = 1; i < 10; i++)
	{
		MyIntVector.Insert(i);
	}

	
	for (MyVector<int>::Iterator i = MyIntVector.begin(); i != MyIntVector.end(); ++i)
	{
		cout << *i << ", ";
	}
	cout << endl;

	

	MyVector<float> MyFloatVector;
	for (size_t i = 1; i < 10; i++)
	{
		MyFloatVector.Insert(i/10);
	}

	for (MyVector<float>::Iterator i = MyFloatVector.begin(); i != MyFloatVector.end(); ++i)
	{
		cout << *i << ", ";
	}
	cout << endl;

	for (auto iter : MyFloatVector)
	{
		cout << *iter << ", ";
	}
	cout << endl;
	
	return 0;
}