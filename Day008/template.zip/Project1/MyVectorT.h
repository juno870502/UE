#pragma once
template<typename T>
class MyVectorT
{
public:
	MyVectorT();
	~MyVectorT();

	void PushBack(T NewValue);
	T& GetValue(int GetIndex);
	int GetSize();
	void Erase(int DeleteIndex);
	int Find(T SearchValue);

	static T Empty;

	T& operator[] (int Index)
	{
		return GetValue(Index);
	}

protected:
	int Size;
	T* Value;

	int Capacity;
};

template<typename T>
inline MyVectorT<T>::MyVectorT()
{
	Capacity = 10;
	Size = 0;

	Value = new T[Capacity];
}

template<typename T>
inline MyVectorT<T>::~MyVectorT()
{
	delete[] Value;
}

template<typename T>
void MyVectorT<T>::PushBack(T NewValue)
{
	if (Capacity <= Size) //����������� ���ڶ�ϱ� �뷮 �߰�, ���� ����, ����, �̵�
	{
		Capacity = Capacity * 2;
		T* Temp = new T[Capacity];
		for (int i = 0; i < Size; ++i)
		{
			Temp[i] = Value[i];
		}
		//memcpy(Temp, Value, sizeof(T)*Size);
		Temp[Size] = NewValue;
		delete[] Value;
		Value = Temp; //Temp�� Value�� ���� ���� ����Ŵ
		Size++;
		//std::cout << "Allocate" << std::endl;
	}
	else //���� �ڷ� ��ġ�ڿ� �߰���
	{
		Value[Size] = NewValue;
		Size++;
	}
}

template<typename T>
inline T& MyVectorT<T>::GetValue(int GetIndex)
{
	if (Size > GetIndex)
	{
		return Value[GetIndex];
	}

	return Empty;
}

template<typename T>
inline int MyVectorT<T>::GetSize()
{
	return Size;
}

template<typename T>
inline void MyVectorT<T>::Erase(int DeleteIndex)
{
	if (DeleteIndex < 0 || DeleteIndex > Size)
	{
		return;
	}
	for (int i = DeleteIndex; i < Size-1; ++i)
	{
		Value[i] = Value[i + 1];
	}
	//memcpy(&Value[DeleteIndex], &Value[DeleteIndex + 1],
	//	sizeof(T) * (Size - DeleteIndex - 1));

	Size--;
}

template<typename T>
inline int MyVectorT<T>::Find(T SearchValue)
{
	for (int i = 0; i < Size; ++i)
	{
		if (Value[i] == SearchValue)
		{
			return i;
		}
	}
	return -1;
}

template<typename T>
T MyVectorT<T>::Empty;