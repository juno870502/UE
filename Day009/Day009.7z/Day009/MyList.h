#pragma once
template <typename T>
class Node
{
public:
	T Data;
	Node* Next;
	Node* Prev;

	Node<T>& operator ++() { return *(this->Next); }
	bool operator !=(const Node<T>& rhs) { if (this->Data != rhs.Data)return true; else return false; }
	//Node<T>* operator *() { return this; }

	//const value_type& operator*() const;

private:

};

template <typename T>
class MyList
{
public:
	MyList();
	~MyList();

	//void Insert(T Value);
	void PushBack(T Value);
	void PushFront(T Value);
	void InsertBefore(Node<T>* node, T Value);
	void InsertAfter(Node<T>* node, T Value);

	inline Node<T>* begin() { return Head->Next; }
	inline Node<T>* end() { return Tail->Prev; }
	inline Node<T>* rbegin() { return Tail->Prev; }
	inline Node<T>* rend() { return Head->Next; }
	

	void Remove(T Value);
	Node<T>* Remove(Node<T>* DeleteNode);
	void RemoveIndex(int Index);
	void RemoveAll();

	Node<T>* Find(T Value);
	Node<T>* RFind(T Value);

	Node<T>* GetHead();
	inline int GetSize(){return Size;}
protected:
	Node<T>* Head;
	Node<T>* Tail;
	int Size;
};

template <typename T>
inline MyList<T>::MyList()
{
	Head = new Node<T>;
	Tail = new Node<T>;
	Head->Next = Tail;
	Tail->Prev = Head;

	Size = 0;
}


template <typename T>
inline MyList<T>::~MyList()
{
	RemoveAll();
	delete Tail;
	delete Head;
}

template<typename T>
inline void MyList<T>::PushBack(T Value)
{
	//�ű� ��� �ʱ�ȭ
	Node<T>* NewNode = new Node<T>;
	NewNode->Data = Value;
	NewNode->Next = nullptr;

	//��� ������ ��
	Node<T>* PrevNode = Tail->Prev;
	PrevNode->Next = NewNode;
	Tail->Prev = NewNode;
	NewNode->Next = Tail;
	NewNode->Prev = PrevNode;

	Size++;
}

template<typename T>
inline void MyList<T>::PushFront(T Value)
{
	//�ű� ��� �ʱ�ȭ
	Node<T>* NewNode = new Node<T>;
	NewNode->Data = Value;
	NewNode->Next = nullptr;

	//��� ������ ��
	Node<T>* NextNode = Head->Next;
	NextNode->Prev = NewNode;
	Head->Next = NewNode;
	NewNode->Next = NextNode;
	NewNode->Prev = Head;

	Size++;
}

template <typename T>
inline void MyList<T>::InsertBefore(Node<T>* node, T Value)
{
	//�ű� ��� �ʱ�ȭ
	Node<T>* NewNode = new Node<T>;
	NewNode->Data = Value;
	NewNode->Next = nullptr;

	NewNode->Prev = node->Prev;
	NewNode->Next = node;
	node->Prev->Next = NewNode;
	node->Prev = NewNode;

	Size++;
}

template <typename T>
inline void MyList<T>::InsertAfter(Node<T> * node, T Value)
{
	//�ű� ��� �ʱ�ȭ
	Node<T>* NewNode = new Node<T>;
	NewNode->Data = Value;
	NewNode->Next = nullptr;

	NewNode->Prev = node;
	NewNode->Next = node->Next;
	node->Next->Prev = NewNode;
	node->Next = NewNode;

	Size++;
}

template <typename T>
inline void MyList<T>::Remove(T Value)
{
	//Node* Prev = Head;
	//Node* CurrentTemp = Head->Next;
	//while (CurrentTemp && CurrentTemp->Data != Value)
	//{
	//	Prev = CurrentTemp;
	//	CurrentTemp = CurrentTemp->Next;
	//}
	////����ó��
	//if (!CurrentTemp)
	//{
	//	return;
	//}
	//Prev->Next = CurrentTemp->Next;
	//Size--;
	//delete CurrentTemp;
	//������ũ�帮��Ʈ
	Node<T>* RemoveNode = Head->Next;
	while (RemoveNode->Data != Value)
	{
		RemoveNode = RemoveNode->Next;
		if (RemoveNode == Tail)
		{
			return;
		}
	}
	RemoveNode->Prev->Next = RemoveNode->Next;
	RemoveNode->Next->Prev = RemoveNode->Prev;
	Size--;
	delete RemoveNode;
}

template<typename T>
inline Node<T>* MyList<T>::Remove(Node<T>* DeleteNode)
{
	if (DeleteNode == Head || DeleteNode == Tail || DeleteNode == nullptr)
	{
		return;
	}
	Node<T>* NextNode = DeleteNode->Prev;
	DeleteNode->Prev->Next = DeleteNode->Next;
	DeleteNode->Next->Prev = DeleteNode->Prev;
	Size--;
	delete DeleteNode;
	return NextNode;
}

template <typename T>
inline void MyList<T>::RemoveIndex(int Index)
{
	//Node* Prev = Head;
	//Node* CurrentTemp = Head->Next;
	//int i = 0;
	//while (CurrentTemp && i != Index)
	//{
	//	Prev = CurrentTemp;
	//	CurrentTemp = CurrentTemp->Next;
	//	i++;
	//}
	////����ó��
	//if (!CurrentTemp)
	//{
	//	return;
	//}
	//Prev->Next = CurrentTemp->Next;
	//Size--;
	//delete CurrentTemp;
	//������ũ�帮��Ʈ
	Node<T>* RemoveNode = Head->Next;
	for (size_t i = 0; i < Index; i++)
	{
		RemoveNode = RemoveNode->Next;
		if (RemoveNode == Tail)
		{
			return;
		}
	}
	RemoveNode->Prev->Next = RemoveNode->Next;
	RemoveNode->Next->Prev = RemoveNode->Prev;
	Size--;
	delete RemoveNode;
}

template<typename T>
inline void MyList<T>::RemoveAll()
{
	for (Node<T>* Cursor = begin(); Cursor != end(); Cursor = Cursor->Next)
	{
		Cursor = Remove(Cursor); //Remove �Ҷ��� ������ Ž���� ����
	}

	Size = 0;
}

template <typename T>
inline Node<T>* MyList<T>::Find(T Value)
{
	//Node* CurrentTemp = Head->Next;
	//while (CurrentTemp && CurrentTemp->Data != Value)
	//{
	//	CurrentTemp = CurrentTemp->Next;
	//}
	////while (CurrentTemp = CurrentTemp->Next)
	////{
	////	if (CurrentTemp->Data == Value)
	////	{
	////		break;
	////	}
	////}
	////����ó��
	//if (!CurrentTemp)
	//{
	//	return nullptr;
	//}
	//return CurrentTemp;
	//������ũ�帮��Ʈ
	//FindNode = FindNode->Next
	for (Node<T>* FindNode = begin(); FindNode != end(); FindNode = FindNode->Next)
	{
		if (FindNode->Data == Value)
		{
			return FindNode;
		}
		//FindNode = FindNode->Next;
	}
	return nullptr;
}

template <typename T>
inline Node<T>* MyList<T>::RFind(T Value)
{
	Node<T>* FindNode = Tail->Prev;
	for (size_t i = 0; i < this->Size; i++)
	{
		if (FindNode->Data == Value)
		{
			break;
		}
		FindNode = FindNode->Prev;
	}
	return FindNode;
}

template <typename T>
inline Node<T>* MyList<T>::GetHead()
{
	return Head->Next;
}