#include <iostream>
#include "MyList.h"
#include "main.h"

using namespace std;

int main()
{
	MyList<int> TestList;
	TestList.PushBack(1);
	TestList.PushBack(2);
	TestList.PushBack(3);
	TestList.PushBack(4);
	TestList.PushBack(5);
	TestList.PushFront(6);
	TestList.PushFront(7);
	TestList.PushFront(8);
	TestList.PushFront(9);

	/*TestList.Remove(3);
	TestList.Remove(4);
	TestList.Remove(9);
	TestList.Remove(100);
	TestList.RemoveIndex(0);
	TestList.RemoveIndex(1);
	TestList.RemoveIndex(5);*/

	TestList.RemoveIndex(0);
	TestList.RemoveIndex(1);
	TestList.RemoveIndex(2);
	TestList.RemoveIndex(3);
	TestList.RemoveIndex(5);

	TestList.Remove(2);
	TestList.Remove(9);
	TestList.Remove(3);

	TestList.InsertBefore(TestList.Find(4), 3);
	TestList.InsertAfter(TestList.Find(6), 5);

	cout << "Int Size : " << TestList.GetSize() << endl;
	cout << "Int Find : " << TestList.RFind(2)->Data << endl;

	Node<int>* Current = TestList.GetHead();
	for (size_t i = 0; i < TestList.GetSize(); i++)
	{
		cout << Current->Data << endl;
		Current = Current->Next;
	}

	/*for (auto iter : TestList)
	{
		cout << iter.Data << endl;
	}*/
	

	/*cout << "Find 5 : " << TestList.Find(5)->Data << endl;
	cout << "Find 9 : " << TestList.Find(9)->Data << endl;*/

	MyList<float> TestFloatList;
	TestFloatList.PushBack(1.1f);
	TestFloatList.PushFront(2.2f);
	TestFloatList.PushBack(3.3f);
	TestFloatList.PushFront(4.4f);
	TestFloatList.PushBack(5.5f);
	TestFloatList.PushFront(6.6f);
	TestFloatList.PushBack(7.7f);
	TestFloatList.PushFront(8.8f);
	TestFloatList.PushBack(9.9f);
	TestFloatList.Remove(2.2f);
	TestFloatList.InsertAfter(TestFloatList.Find(3.3f), 3.5f);

	cout << "Float Size : " << TestFloatList.GetSize() << endl;

	Node<float>* CurrentFloat = TestFloatList.GetHead();
	for (size_t i = 0; i < TestFloatList.GetSize(); i++)
	{
		cout << (float)CurrentFloat->Data << endl;
		CurrentFloat = CurrentFloat->Next;
	}

	return 0;
}