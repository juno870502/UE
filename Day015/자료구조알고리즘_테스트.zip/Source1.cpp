#include<iostream>

using namespace std;

int No1Array[] = {
	1,2,3
};


void No1Func()
{
	int count = sizeof(No1Array) / sizeof(int);
	int Num = (1 << count);
	for (int i = 0; i < Num; i++)
	{
		for (int j = 0; j < count; j++)
		{
			if (i & (1 << j))
			{
				cout << No1Array[j] << ",";
			}
		}
		cout << endl;
	}
}


int main()
{
	No1Func();

	return 0;
}