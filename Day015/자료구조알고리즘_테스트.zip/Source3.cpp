#include<iostream>
using namespace std;
float Point1[] = {
	0,0
};
float Point2[] = {
	10,10
};
float Circle[] = {
	20,20,1
};

bool No3Func(float* Point1, float* Point2, float* Circle)
{
	float Point1x = Point1[0];
	float Point1y = Point1[1];
	float Point2x = Point2[0];
	float Point2y = Point2[1];
	float CircleX = Circle[0];
	float CircleY = Circle[1];
	float CircleR = Circle[2];
	//ax + by + c = 0
	//a = y1 - y2
	//b = x2 - x1
	//c = x1y2 - x2y1
	float A = Point1y - Point2y;
	float B = Point2x - Point1x;
	float C = Point1x * Point2y - Point2x * Point1y;
	float D = abs(A * CircleX + B * CircleY + C);
	float E = sqrt(A * A + B * B);
	float Distance = abs(A * CircleX + B * CircleY + C) / sqrt(A * A + B * B);

	if (Distance <= CircleR)
	{
		return true;
	}
	else
	{
		return false;
	}

}
int main()
{
	if (No3Func(Point1, Point2, Circle))
	{
		cout << "�浹" << endl;
	}
	else
	{
		cout << "�浹X" << endl;
	}
	return 0;
}