#include<iostream>
#include<queue>
#include<stack>
using namespace std;

#define MAX 5
int Maze[MAX][MAX] = {
	{0, 1, 1, 1, 0},
	{0, 0, 0, 0, 0},
	{1, 0, 1, 1, 1},
	{1, 0, 1, 1, 1},
	{1, 0, 0, 0, 0}
};

class Point
{
public:
	Point(int x = 0, int y = 0) { X = x; Y = y; }
	void PrintPoint() { cout << "(" << X << ", " << Y << ")" << endl; }

	bool operator==(const Point& rhs) { return(this->X == rhs.X && this->Y == rhs.Y); }
	Point& operator=(Point& rhs) { X = rhs.GetX(); Y = rhs.GetY(); return *this; }
	Point& UP() { X = X; Y = Y - 1; return *this; }
	Point& DOWN() { X = X; Y = Y + 1; return *this;}
	Point& RIGHT() { X = X + 1; Y = Y; return *this; }
	Point& LEFT() { X = X - 1; Y = Y; return *this;}

	int GetX() { return X; }
	int GetY() { return Y; }
	void SetXY(int x, int y) { this->X = x; this->Y = y; }
	void SetX(int x) { this->X = x; }
	void SetY(int y) { this->Y = y; }
protected:
	int X;
	int Y;
};


bool CanMove(Point& Current)
{
	int DirX[] = { 0, 1, 0, -1 };
	int DirY[] = { -1, 0, 1, 0 };
	Point Next;
	for (size_t i = 0; i < 4; i++)
	{
		Next.SetXY(Current.GetX() + DirX[i], Current.GetY() + DirY[i]);
		if (Next.GetX() < 0 || Next.GetY() < 0 || Next.GetX() >= MAX || Next.GetY() >= MAX)
		{
			continue;
		}
		if (Maze[Next.GetY()][Next.GetX()] == 0)
		{
			Current = Next;
			return true;
		}
	}
	return false;
}

void DFS_Trace(stack<Point> P)
{
	stack<Point> Reverse;
	while (!P.empty())
	{
		Reverse.push(P.top());
		P.pop();
	}
	while (!Reverse.empty())
	{
		Point Temp = Reverse.top();
		cout << "(" << Temp.GetX() << ", " << Temp.GetY() << ")" << endl;
		Reverse.pop();
	}
}

void DFSEscape()
{
	int DirX[] = { 0, 1, 0, -1 };
	int DirY[] = { -1, 0, 1, 0 };
	Point Current;
	Point Goal(MAX - 1, MAX - 1);
	stack<Point> Path;
	while (true)
	{
		Maze[Current.GetY()][Current.GetX()] = 2;
		Point Prev = Current;
		if (CanMove(Current))
		{
			Path.push(Prev);
		}
		else
		{
			Point Temp = Path.top();
			Path.pop();
			Maze[Current.GetY()][Current.GetX()] = 3;
			Current = Temp;
		}

		if (Current == Goal)
		{
			Path.push(Current);
			break;
		}
	}
	DFS_Trace(Path);
}



int main()
{
	DFSEscape();
	return 0;
}