#include <iostream>
#include <vector>
#include<algorithm>

using namespace std;

//�Է� �迭
vector<int> Array = {
	1, 5, 2, 6, 3, 7, 4
};
//�Է� ���ɾ�
vector<vector<int>> Commands = {
	{2,5,3},
	{4,4,1},
	{1,7,3}
};

vector<int> Solution(vector<int> array, vector<vector<int>> commands) 
{
	vector<int> answer;

	for (int k = 0; k < commands.size(); k++)
	{
		vector<int> tempArray;
		for (int i = commands[k][0]-1; i <= commands[k][1]-1; i++)
		{
			tempArray.push_back(array[i]);
		}
		sort(tempArray.begin(), tempArray.end());
		answer.push_back(tempArray[commands[k][2]-1]);
	}
	return answer;
}

int main()
{
	vector<int> answer = Solution(Array, Commands);
	for (auto a : answer)
	{
		cout << a << ", ";
	}
	return 0;
}